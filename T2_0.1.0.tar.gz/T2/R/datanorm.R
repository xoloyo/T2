#' a dataset inside T2 package
#'
#' It is used to demonstrate this package
#'@docType data
#'@name datanorm
NULL
