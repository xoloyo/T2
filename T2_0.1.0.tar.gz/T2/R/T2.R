#' @title T2
#'
#' @description This package computes t value of a sample
#'              from normal distribution population.
#' It is used to demonstrate how to create an R package.
#'
#' @param x: a sample randomly sampled from a normal population
#' @param mu: mean of the normal population
#' @return t value
#' @export
#'
#' @examples
#' data(datanorm,package="T2")
#' library("T2")
#' T2(x=datanorm, mu=8)
#'
#' Notes: The sample data "datanorm" is acquired by the way as follows:
#'        set.seed(111);
#'        datanorm <- rnorm(n=88, mean=8, sd=1);
#'        save(datanorm, file = "datanorm.rda")
#'
#'        R returns -0.0662679.
#'
T2 <- function(x, mu)
  {
  (mean(x)-mu)/(sd(x)/sqrt(length(x)))
  }

